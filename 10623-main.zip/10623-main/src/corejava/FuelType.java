package corejava;

public enum FuelType {

	Electric,Diesel,Petrol,Hyrbid
}
