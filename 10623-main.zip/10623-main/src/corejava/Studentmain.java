package corejava;

public class Studentmain {
	int id;
	String name;

	Studentmain(int id, String name) {
		this.id = id;
		this.name = name;
	}

}
