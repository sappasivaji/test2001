package corejava;

public enum TrafficSignal
{
   RED,YELLLOW,GREEN
}
