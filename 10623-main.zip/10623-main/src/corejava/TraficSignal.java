package corejava;

public enum TraficSignal 
{
	RED, YELLOW, GREEN

}
