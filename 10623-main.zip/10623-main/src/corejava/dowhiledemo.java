package corejava;

public class dowhiledemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i = 100;
		do {
			System.out.println("value of i: " + i);
			i++;
		} while (i <= 10);

	}

}
