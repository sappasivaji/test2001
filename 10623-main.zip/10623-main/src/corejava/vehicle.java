package corejava;

public abstract class vehicle {
 abstract void start();

	void stop() {
		System.out.println("vehicle stopped");
	}

}

