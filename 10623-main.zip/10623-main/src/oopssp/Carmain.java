package oopssp;

public class Carmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Engine eng = new Engine();
		eng.startEngine();
		eng.stopEngine();
		//Cars ob = new Cars("kiaseltos",eng);
		//ob.drive();

	}

}
