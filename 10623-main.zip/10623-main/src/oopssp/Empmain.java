package oopssp;

public class Empmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Manager m = new Manager(1,"Alice",50000);
		m.display();
		
	}

}
