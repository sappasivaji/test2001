package oopssp;

public class Engine {
	public void startEngine() {
		System.out.println("Engine started.");
	}

	public void stopEngine() {
		System.out.println("Engine stopped.");
	}

}
