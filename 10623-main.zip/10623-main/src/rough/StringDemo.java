package rough;

public class StringDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "Hello World";
		//str=str.concat("java");
		System.out.println(str);
		String str1="Hello World ";
		 str1.concat("java");
		System.out.println(str1);
		System.out.println(str);
	}

}
