package rough;

public class stu {
	
	int id;
	String name;

	stu(int i, String n) {
		id = i;
		name = n;
	}

}
